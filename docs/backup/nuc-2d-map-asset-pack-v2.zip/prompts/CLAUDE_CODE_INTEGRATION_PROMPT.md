# Claude Code 集成 Prompt — 中北大学 2D 校园图 overlay

你在仓库 `campus-shortest-path-navigation-system` 中工作。请把当前前端 Demo 的抽象 SVG 地图升级为基于 `campus-layout.json` 的 2D 校园图 overlay。

## 必须读取的文件

- `README.md`
- `CLAUDE.md`
- `assets/prototype/campus-nav-prototype/js/app.js`
- `assets/prototype/campus-nav-prototype/css/styles.css`
- `assets/prototype/campus-nav-prototype/data/routes.json`
- `assets/prototype/campus-nav-prototype/data/campus-layout.json`
- 本资产包内的 `docs/integration-plan.md`
- 本资产包内的 `docs/manual-acceptance-checklist.md`

## 核心约束

1. **不改 C 端 Dijkstra 算法**（`src/`、`include/`、`Makefile` 均不改动）。
2. **不引入 React / Vue / npm / 构建工具**。
3. **保持纯 HTML / CSS / JS**。
4. **保留 `routes.json` fallback 逻辑**：加载失败或无数据时仍使用 `FALLBACK_PLACES` / `FALLBACK_EDGES`。
5. **展示层 source of truth 改为 `campus-layout.json`**；算法结果 source of truth 仍是 `routes.json`。
6. **最小化改动**：只改 `app.js` 的 `renderMap()`、新增 `loadCampusLayout()`，以及少量 CSS。
7. **SVG 坐标系**：`viewBox` 使用 `campus-layout.json` 的 `map.width` / `map.height`（当前为 1024 × 682，以官方图原始尺寸为准）。

## 具体任务

### 1. 新增 `loadCampusLayout()`

在 `app.js` 中：

```js
let campusLayout = null;

async function loadCampusLayout() {
  try {
    const res = await fetch('data/campus-layout.json?_=' + Date.now(), { cache: 'no-store' });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    campusLayout = await res.json();
  } catch (err) {
    console.warn('未能加载 campus-layout.json，使用内置坐标。', err);
    campusLayout = null;
  }
}
```

在 `initPage()` 中，于 `loadCProgramData()` 之后调用 `await loadCampusLayout()`，再调用 `initMapPlaceholders()` 等依赖地图的函数。

### 2. 改造 `renderMap(activePath = [])`

保持函数签名不变，内部逻辑改为：

- 若 `campusLayout` 加载成功：
  - `viewBox="0 0 1600 900"`（读取 `map.width` / `map.height`）。
  - 先渲染底图：`<image class="campus-map-image" href="images/nuc-campus-map-official.jpg" width="1024" height="682" />`（从 `map.image` / `map.width` / `map.height` 读取）。
  - 边使用 `campus-layout.json` 的 `edgePolylines` 渲染为 `<polyline class="map-edge ...">`。
  - 若某条边没有对应 polyline，用两点直线 fallback。
  - `activePath` 中的边追加 `active` class。
  - marker 坐标使用 `campusLayout.places[id].x / y`。
  - label 位置使用 `labelOffset`。
- 若 `campusLayout` 为 `null`：
  - 保持原有抽象网格地图逻辑（当前 `renderMap` 的实现）。

### 3. CSS 调整

在 `styles.css` 中新增/确保：

```css
.campus-map-image { pointer-events: none; }
.map-edge { fill: none; stroke: #94a3b8; stroke-width: 8; stroke-linecap: round; stroke-linejoin: round; opacity: 0.9; }
.map-edge.active { stroke: var(--primary); stroke-width: 10; }
.map-node { cursor: pointer; }
```

保留 `.map-node-bg`、`.map-node-label` 等已有样式。

### 4. 更新文档

同步更新以下文件（只改与地图相关的段落，不要重写整篇文档）：

- `README.md`：说明新增 2D 校园图资产、放置位置、如何替换为官方图。
- `CONTEXT.md`：记录 2D 地图 overlay 的设计决策和数据契约。
- `docs/handoff/运行说明.md`：说明前端运行方式不变，新增底图文件路径。

### 5. 测试与验收

完成后人工检查：

```bash
cd assets/prototype/campus-nav-prototype
python -m http.server 8081
```

浏览器打开 `http://localhost:8081/query.html`：

- 默认页能看到 2D 校园底图。
- 选择任意起终点，最短路径在地图上以高亮 polyline 显示。
- 控制台无新增报错。
- 不选择地点 / 起终点相同 / 地点不存在等异常提示仍正常工作。
- 删除或重命名 `data/campus-layout.json` 后刷新，页面仍能回退到旧版抽象地图。

## 提交建议

```bash
git add -A
git commit -m "feat(frontend): add 2d campus map overlay from campus-layout.json"
```

## 边界说明

- 当前底图已使用中北大学本科招生信息网官方校园平面图，但**坐标为草稿值**（由示意 schematic 等比缩放得到），尚未根据真实建筑位置精确校准。
- 坐标校准流程见本资产包 `docs/model-to-2d-workflow.md` 和 `source_materials/official-map-and-model-source-notes.md`。
- 请使用 `tools/coordinate-debug-tool.html` 点击官方图上的建筑中心，修正 `campus-layout.json` 中 `places` 和 `edgePolylines` 的坐标。
