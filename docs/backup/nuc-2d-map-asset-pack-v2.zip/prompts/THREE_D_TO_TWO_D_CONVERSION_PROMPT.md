# 3D 校园模型 → 2D 平面图转换 Prompt / 工作流

本文件描述：当获得真实 3D 校园模型（`.glb` / `.gltf` / `.obj` / `.fbx` / `.blend`）时，如何生成可用于本项目的 2D 平面图及坐标数据。

## 前置条件

1. 3D 模型文件，包含校园主要建筑、道路、绿地。
2. 模型使用真实世界坐标系，或至少包含可测量的比例尺。
3. 已知投影方式（推荐：正射投影 / orthographic / top-down）。

## 推荐工具链

- Blender（免费，可导入 glb/gltf/obj/fbx/blend）
- Python + `trimesh` / `pygltflib` / `PIL`
- QGIS（如需与真实地理坐标对齐）

## 转换步骤

### Step 1 — 统一坐标系

在 Blender 或脚本中：

1. 将模型世界坐标归一化到原点。
2. 确定上方向（通常是 Z 轴向上）。
3. 记录缩放因子：`modelUnitToMeter`。

### Step 2 — 选择投影

推荐正射投影（Orthographic），相机垂直向下：

- 位置：`(centerX, centerY, highZ)`，look-at 指向地面中心。
- 投影：orthographic，范围覆盖整个校园。
- 输出分辨率：建议 ≥ 2048 × 2048。

### Step 3 — 投影 3D 顶点到 2D

对模型中每个 marker / 建筑中心点 `(mx, my, mz)`，正射投影到 2D：

```
screenX = (mx - boundsMinX) / (boundsMaxX - boundsMinX) * imageWidth
screenY = imageHeight - (my - boundsMinY) / (boundsMaxY - boundsMinY) * imageHeight
```

如果使用透视投影，则需要相机内参矩阵进行透视除法。

### Step 4 — 生成道路 polyline

1. 在 3D 模型中提取道路中心线（曲线/边线）。
2. 对道路中心线采样点，按相同公式投影到 2D。
3. 按地点 pair 组合成 `edgePolylines`。

### Step 5 — 生成 campus-layout.json

使用本资产包 `tools/project_3d_markers_to_2d.py` 的模板，填入：

- `map.image`：投影输出的 PNG/JPG 路径。
- `places.*.x/y`：投影后的屏幕坐标。
- `edgePolylines`：投影后的道路采样点。
- `calibration.metersPerPixel`：真实距离 / 像素距离。

### Step 6 — 验证

1. 把输出图片放到 `images/`。
2. 更新 `campus-layout.json`。
3. 用 `tools/coordinate-debug-tool.html` 检查 marker 是否与底图对齐。
4. 运行前端，检查路径高亮是否沿道路走。

## 给 Claude Code 的指令模板

当拿到 3D 模型后，把以下内容连同模型文件一起交给 Claude Code：

```text
我在仓库 campus-shortest-path-navigation-system 的 source_materials/ 目录下放置了 3D 校园模型文件：
- source_materials/campus-model.glb

请完成：
1. 读取 3D 模型，提取主要建筑位置（教学楼、图书馆、食堂、宿舍区、体育馆、实验楼、校医院、行政楼、操场）。
2. 使用正射投影生成一张 1600×900 的 2D 校园平面图 PNG，保存到 assets/prototype/campus-nav-prototype/images/nuc-campus-map-official.png。
3. 把 3D 坐标按本仓库 assets/prototype/campus-nav-prototype/data/campus-layout.json 的格式，生成新的坐标与 edgePolylines。
4. 更新 campus-layout.json 的 map.image 指向新生成的 PNG。
5. 不改动 C 端算法和 routes.json 的 distance 数据。
6. 用 tools/coordinate-debug-tool.html 验证 marker 位置。

可参考 prompts/THREE_D_TO_TWO_D_CONVERSION_PROMPT.md 和 docs/model-to-2d-workflow.md。
```

## 注意事项

- 如果 3D 模型没有道路网络，需要手工在 `coordinate-debug-tool.html` 中标定道路拐点。
- 真实距离以 `routes.json` 为准；`metersPerPixel` 仅用于展示层参考。
- 建议保留原始 3D 模型和投影参数文件，方便后续迭代。
