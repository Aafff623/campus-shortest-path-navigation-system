# 3D 模型放置说明

如果你已经获得真实 3D 校园模型文件，请放到本目录下：

```
source_materials/
├── campus-model.glb          # 推荐格式
├── campus-model.gltf
├── campus-model.obj
├── campus-model.fbx
└── campus-model.blend
```

然后把以下信息一并交给 Claude Code：

1. 模型文件路径。
2. 模型坐标系（哪个轴朝上、单位）。
3. 需要投影的 9 个地点在模型中的大致位置或命名。
4. 是否包含道路网络。

参考 `prompts/THREE_D_TO_TWO_D_CONVERSION_PROMPT.md` 生成完整转换指令。
