# 中北大学 2D 校园图资产包 — README

**版本**：0.2.1  
**定位**：课程设计 Demo 用 2D 校园图 overlay。底图已替换为中北大学本科招生信息网官方校园平面图；坐标为草稿值，需进一步人工标定。

## 快速开始

把资产包复制到项目根目录：

```bash
unzip nuc-2d-map-asset-pack-v2.zip
cp -R nuc-2d-map-asset-pack-v2/project-files/* .
```

然后打开 `prompts/CLAUDE_CODE_INTEGRATION_PROMPT.md`，把内容交给 Claude Code 执行集成。

## 包里有什么

```text
nuc-2d-map-asset-pack-v2/
├── README.md
├── MANIFEST.md
├── project-files/              # 可直接复制到仓库的文件
│   └── assets/prototype/campus-nav-prototype/
│       ├── images/
│       │   ├── nuc-campus-map-official.jpg      # 官方校园平面图
│       │   ├── nuc-campus-map-schematic-v2.svg  # 示意底图（fallback）
│       │   └── nuc-campus-map-schematic-v2.png
│       ├── data/
│       │   └── campus-layout.json
│       └── tools/
│           └── coordinate-debug-tool.html
├── prompts/                    # 给 Claude Code 的指令
│   ├── CLAUDE_CODE_INTEGRATION_PROMPT.md
│   └── THREE_D_TO_TWO_D_CONVERSION_PROMPT.md
├── docs/                       # 集成与转换文档
│   ├── integration-plan.md
│   ├── coordinate-conversion.md
│   ├── model-to-2d-workflow.md
│   ├── manual-acceptance-checklist.md
│   └── placement-guide.md
├── source_materials/           # 原始素材说明与占位
│   ├── official-map-and-model-source-notes.md
│   ├── PLACE_3D_MODELS_HERE.md
│   └── model-markers.template.json
├── compressed/                 # 压缩上下文，便于复用
│   ├── compact-context.md
│   └── campus-layout.min.json
└── tools/
    ├── generate_map.py         # SVG/PNG 生成脚本
    └── project_3d_markers_to_2d.py
```

## 重要说明

- 底图已使用中北大学本科招生信息网官方校园平面图。
- **坐标为草稿值**：由示意 schematic 等比缩放到官方图尺寸得到，尚未根据真实建筑位置精确校准。
- 路径距离仍以 C 程序导出的 `routes.json` 为准。
- 展示层坐标以 `campus-layout.json` 为准。
- 官方校园平面图来源：`https://zbzs.nuc.edu.cn/info/1002/2385.htm`。

## 坐标校准

1. 启动 `tools/coordinate-debug-tool.html`（用本地 HTTP 服务器打开）。
2. 在官方图上点击每个地点的建筑中心，记录坐标。
3. 更新 `campus-layout.json` 中对应 `places` 的 `x`、`y`。
4. 沿道路点击拐点，更新 `edgePolylines`。
5. 把 Claude Code 集成 Prompt 重新执行一次，确保前端读取新配置。

## 版权与来源

- 示意底图：本资产包生成，仅用于课程设计 Demo。
- 官方图：请从中北大学本科招生信息网获取。
- 3D 模型：需由学校或项目方提供。
