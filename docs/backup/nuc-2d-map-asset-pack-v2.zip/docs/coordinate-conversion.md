# 坐标换算规则 coordinate-conversion

## 当前坐标系

- 画布尺寸：1600 × 900（像素）
- 原点：左上角 (0, 0)
- X 轴：向右递增
- Y 轴：向下递增
- 坐标类型：整数像素坐标

## 与旧坐标的换算

旧版 `app.js` 使用 `viewBox="0 0 760 390"`。新版使用 1600 × 900。
若需把旧坐标 `(x_old, y_old)` 换算到新坐标系：

```
x_new = round(x_old * 1600 / 760)
y_new = round(y_old * 900 / 390)
```

反向换算：

```
x_old = round(x_new * 760 / 1600)
y_old = round(y_new * 900 / 390)
```

## 真实世界距离换算

当使用官方底图或 3D 投影时：

```
metersPerPixel = 真实距离(米) / 底图像素距离
distanceMeters = pixelDistance * metersPerPixel
```

注意：展示层 `distance` 仍以 `routes.json` 为准；`metersPerPixel` 仅用于验证底图比例。

## 3D → 2D 正射投影

对 3D 顶点 `(mx, my, mz)`，相机垂直向下，校园范围 `[minX, maxX] × [minY, maxY]`：

```
screenX = (mx - minX) / (maxX - minX) * imageWidth
screenY = imageHeight - (my - minY) / (maxY - minY) * imageHeight
```

## 道路 polyline

每条 `edgePolylines` 是由多个 `[x, y]` 组成的折线，渲染时连接为 `M x0,y0 L x1,y1 ...`。
