# 人工验收清单 manual-acceptance-checklist

## 环境准备

```bash
cd assets/prototype/campus-nav-prototype
python -m http.server 8081
```

浏览器访问 `http://localhost:8081`。

## 验收项

### 首页 index.html

- [ ] 页面能正常加载，无控制台报错。
- [ ] 地图卡片显示 2D 校园底图。
- [ ] 地点 marker 位置合理，标签可读。

### 路径查询页 query.html

- [ ] 选择任意两个不同地点，点击查询。
- [ ] 结果卡片正常显示最短距离和文字路径。
- [ ] 地图上的高亮路径沿道路 polyline 走，不穿楼。
- [ ] 起点/终点相同：提示错误。
- [ ] 未选择地点：提示错误。

### 数据管理页 data.html

- [ ] 地点表格中的坐标列显示 `campus-layout.json` 中的 x、y。
- [ ] 路径表格正常显示。

### 回退测试

- [ ] 临时重命名 `data/campus-layout.json`。
- [ ] 刷新页面，地图应回退到旧版抽象网格地图。
- [ ] 恢复文件名，重新刷新，2D 底图恢复。

### 样式与主题

- [ ] 蓝色、暗色等主题下，地图 marker 和高亮路径可见。
- [ ] 地图在移动端缩小后仍可读（文字可能重叠，但无错位）。

### 文档

- [ ] `README.md` 已说明 2D 地图资产。
- [ ] `CONTEXT.md` 已记录设计决策。
- [ ] `docs/handoff/运行说明.md` 已更新。

## 通过标准

所有验收项通过，方可提交并 push。
