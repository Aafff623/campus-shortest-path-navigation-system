# 集成计划 integration-plan

## 目标

将当前前端 Demo 的抽象 SVG 地图替换为基于 `campus-layout.json` 的 2D 校园图 overlay。

## 集成范围

- 修改：`assets/prototype/campus-nav-prototype/js/app.js`
- 修改：`assets/prototype/campus-nav-prototype/css/styles.css`
- 新增：`assets/prototype/campus-nav-prototype/images/nuc-campus-map-schematic-v2.svg`
- 新增：`assets/prototype/campus-nav-prototype/images/nuc-campus-map-schematic-v2.png`
- 新增：`assets/prototype/campus-nav-prototype/data/campus-layout.json`
- 新增：`assets/prototype/campus-nav-prototype/tools/coordinate-debug-tool.html`
- 更新：`README.md`、`CONTEXT.md`、`docs/handoff/运行说明.md`
- 不改动：`src/`、`include/`、`Makefile`、`assets/data/routes.json`

## 集成步骤

1. 复制 `project-files/*` 到仓库根目录。
2. 把 `prompts/CLAUDE_CODE_INTEGRATION_PROMPT.md` 交给 Claude Code。
3. Claude Code 按 Prompt 修改 `app.js` 和 `styles.css`。
4. 本地启动前端：`python -m http.server 8081`。
5. 按 `docs/manual-acceptance-checklist.md` 人工验收。
6. 提交 commit：`feat(frontend): add 2d campus map overlay from campus-layout.json`。

## 回退策略

- 删除或重命名 `data/campus-layout.json` 后，前端应自动回退到旧版抽象地图。
- 保留 `FALLBACK_PLACES` / `FALLBACK_EDGES` 不变。

## 风险

- 当前底图为示意性质，非真实地理数据。
- 若后续替换官方图，需重新标定坐标。
