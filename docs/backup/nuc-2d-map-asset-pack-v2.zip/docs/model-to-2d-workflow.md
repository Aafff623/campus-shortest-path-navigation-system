# 3D 模型 → 2D 平面图工作流 model-to-2d-workflow

## 适用场景

已获得真实 3D 校园模型（`.glb` / `.gltf` / `.obj` / `.fbx` / `.blend`），需要生成可用于本项目的 2D 平面图。

## 工作流

```mermaid
graph TD
    A[获取 3D 模型] --> B[导入 Blender / Python]
    B --> C[归一化坐标系与比例尺]
    C --> D[设置正射相机]
    D --> E[渲染 2D 平面图 PNG]
    E --> F[提取建筑 marker 3D 坐标]
    F --> G[投影到 2D 屏幕坐标]
    G --> H[提取道路中心线并采样]
    H --> I[生成 edgePolylines]
    I --> J[写入 campus-layout.json]
    J --> K[coordinate-debug-tool.html 验证]
    K --> L[前端集成]
```

## 详细步骤

### 1. 导入模型

Blender：
```bash
File > Import > glTF 2.0 (.glb/.gltf)
```

Python（使用 trimesh）：
```python
import trimesh
mesh = trimesh.load('campus.glb')
```

### 2. 归一化

- 确定模型单位到米的换算：`modelUnitToMeter`。
- 将模型中心移到原点，或记录 bounds。

### 3. 正射渲染

Blender 相机设置：
- Type: Orthographic
- Location: `(centerX, centerY, highZ)`
- Rotation: `(0, 0, 0)` 或按需旋转
- Orthographic Scale: `max(maxX-minX, maxY-minY)`
- Resolution: `1600 × 900`

### 4. 投影 marker

对每个地点，在 3D 模型中标记建筑中心 `(mx, my, mz)`，然后：

```python
screenX = (mx - minX) / (maxX - minX) * 1600
screenY = 900 - (my - minY) / (maxY - minY) * 900
```

### 5. 道路 polyline

- 在 3D 中选择道路中心线曲线。
- 均匀采样，例如每 10 米一个点。
- 同样公式投影到 2D。
- 按 `source|target` 组合成 `edgePolylines`。

### 6. 更新 JSON

参考 `model-markers.template.json` 和现有 `campus-layout.json` 格式：

```json
{
  "map": {
    "image": "images/nuc-campus-map-official.png",
    "width": 1600,
    "height": 900
  },
  "places": { ... },
  "edgePolylines": { ... },
  "calibration": {
    "metersPerPixel": 0.35
  }
}
```

### 7. 验证

- 用 `coordinate-debug-tool.html` 检查 marker 是否落在建筑中心。
- 运行前端，检查高亮路径是否沿道路。

## 输出文件

- `images/nuc-campus-map-official.png`
- `data/campus-layout.json`
- （可选）`source_materials/projection-params.json`
