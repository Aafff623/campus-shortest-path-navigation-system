# 文件放置指南 placement-guide

## 复制到项目根目录

把本资产包 `project-files/` 下的内容复制到仓库根目录：

```bash
cp -R nuc-2d-map-asset-pack-v2/project-files/* /path/to/campus-shortest-path-navigation-system/
```

## 最终项目结构

```text
assets/
├── data/
│   └── routes.json                 # C 程序导出，算法 source of truth（不改动）
└── prototype/
    └── campus-nav-prototype/
        ├── css/
        │   └── styles.css          # Claude Code 会小幅新增地图样式
        ├── js/
        │   └── app.js              # Claude Code 会改造 renderMap
        ├── data/
        │   ├── routes.json         # 软链接/复制（可选）
        │   └── campus-layout.json  # 新增：展示层 source of truth
        ├── images/
        │   ├── nuc-campus-map-official.jpg   # 官方校园平面图
        │   ├── nuc-campus-map-schematic-v2.svg
        │   └── nuc-campus-map-schematic-v2.png
        └── tools/
            └── coordinate-debug-tool.html
```

## 替换官方图时

```text
assets/prototype/campus-nav-prototype/images/
├── nuc-campus-map-official.jpg      # 替换后的真实底图
├── nuc-campus-map-schematic-v2.svg  # 可保留为 fallback
└── nuc-campus-map-schematic-v2.png
```

修改 `campus-layout.json`：

```json
"map": {
  "image": "images/nuc-campus-map-official.jpg",
  "previewImage": "images/nuc-campus-map-official.jpg",
  ...
}
```

## 坐标标定工具访问

复制完成后，在 `assets/prototype/campus-nav-prototype/` 目录启动本地服务器：

```bash
cd assets/prototype/campus-nav-prototype
python -m http.server 8081
```

然后在浏览器打开：

```text
http://localhost:8081/tools/coordinate-debug-tool.html
```

> 使用 8081 端口是为了避免与本地其他服务（如 8080）冲突。若 8081 被占用，可换成其他端口。

## 不要移动的文件

- `assets/data/routes.json`：保持原位置，C 程序导出路径不变。
- `src/`、`include/`、`Makefile`：不改动。
