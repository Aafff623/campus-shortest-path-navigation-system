# 资产包清单 MANIFEST

## 生成信息

- 资产包名称：nuc-2d-map-asset-pack-v2
- 版本：0.2.1
- 生成日期：2026-06-24
- 目标项目：campus-shortest-path-navigation-system
- 目标路径：`assets/prototype/campus-nav-prototype/`

## 文件清单

| 路径 | 类型 | 说明 |
|------|------|------|
| `project-files/assets/prototype/campus-nav-prototype/images/nuc-campus-map-official.jpg` | JPEG | 中北大学本科招生信息网官方校园平面图 |
| `project-files/assets/prototype/campus-nav-prototype/images/nuc-campus-map-schematic-v2.svg` | 矢量图 | 2D 校园示意底图 fallback |
| `project-files/assets/prototype/campus-nav-prototype/images/nuc-campus-map-schematic-v2.png` | 位图 | SVG 的 PNG 预览 |
| `project-files/assets/prototype/campus-nav-prototype/data/campus-layout.json` | JSON | 展示层坐标、道路 polyline、元数据 |
| `project-files/assets/prototype/campus-nav-prototype/tools/coordinate-debug-tool.html` | HTML | 坐标标定调试工具 |
| `prompts/CLAUDE_CODE_INTEGRATION_PROMPT.md` | Markdown | 给 Claude Code 的前端集成指令 |
| `prompts/THREE_D_TO_TWO_D_CONVERSION_PROMPT.md` | Markdown | 给 Claude Code 的 3D→2D 转换指令 |
| `docs/integration-plan.md` | Markdown | 集成步骤说明 |
| `docs/coordinate-conversion.md` | Markdown | 坐标换算规则 |
| `docs/model-to-2d-workflow.md` | Markdown | 3D→2D 完整工作流 |
| `docs/manual-acceptance-checklist.md` | Markdown | 人工验收清单 |
| `docs/placement-guide.md` | Markdown | 文件放置指南 |
| `source_materials/official-map-and-model-source-notes.md` | Markdown | 官方图/模型来源说明 |
| `source_materials/PLACE_3D_MODELS_HERE.md` | Markdown | 3D 模型占位说明 |
| `source_materials/model-markers.template.json` | JSON | 3D 模型 marker 模板 |
| `compressed/compact-context.md` | Markdown | 压缩版上下文 |
| `compressed/campus-layout.min.json` | JSON | 压缩版坐标数据 |
| `tools/generate_map.py` | Python | SVG/PNG 生成脚本 |
| `tools/project_3d_markers_to_2d.py` | Python | 3D marker 投影脚本模板 |

## 变更记录

- v0.2.1：接入中北大学本科招生信息网官方校园平面图；坐标改为草稿缩放值；更新坐标调试工具与集成 Prompt。
- v0.2.0：优化 SVG 布局、新增 PNG 预览、补充 3D→2D 转换文档、增加坐标调试工具。
- v0.1.0：初始示意底图（前版资产包）。
