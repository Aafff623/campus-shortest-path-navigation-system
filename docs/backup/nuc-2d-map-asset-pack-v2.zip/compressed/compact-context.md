# 压缩上下文 compact-context

## 项目

`campus-shortest-path-navigation-system` — 中北大学软件学院《数据结构》课设：校园最短路径导航系统。

## 当前任务

把前端 Demo 的抽象 SVG 地图升级为 2D 校园图 overlay。

## 关键文件位置

- 前端：`assets/prototype/campus-nav-prototype/`
- C 导出算法数据：`assets/data/routes.json`
- 新增展示层坐标：`assets/prototype/campus-nav-prototype/data/campus-layout.json`
- 新增底图：`assets/prototype/campus-nav-prototype/images/nuc-campus-map-official.jpg`（中北大学本科招生信息网官方校园平面图）
- 示意底图 fallback：`nuc-campus-map-schematic-v2.svg` / `.png`
- 坐标调试工具：`assets/prototype/campus-nav-prototype/tools/coordinate-debug-tool.html`

## 数据契约

- `routes.json`：places（id, name, type, icon, x, y）、edges（source, target, distance）、routes（start, end, distance, path）。
- `campus-layout.json`：map（image=`nuc-campus-map-official.jpg`, width=1024, height=682）、places（x, y, labelOffset）、edgePolylines（`source|target` → [[x,y], ...]）、calibration。
- 坐标系：1024×682 像素（官方图原始尺寸），原点左上。
- 坐标状态：草稿值，由 schematic 等比缩放得到，待根据真实建筑位置校准。

## 集成要点

- `app.js` 新增 `loadCampusLayout()`，改造 `renderMap()`。
- `renderMap()` 加载 layout 成功时：先画底图 `<image>`，再用 `edgePolylines` 画道路，高亮 activePath。
- 失败时回退到旧版抽象网格地图。
- CSS 新增 `.campus-map-image { pointer-events: none; }`、`.map-edge` polyline 样式。

## 限制

- 底图已替换为官方校园平面图，但**坐标为草稿值**，尚未根据真实建筑位置精确校准。
- 真实 3D→2D 转换需模型文件 + 正射投影 + 重新标定坐标。
- 官方平面图来源：`https://zbzs.nuc.edu.cn/info/1002/2385.htm`。

## Claude Code 指令

见 `prompts/CLAUDE_CODE_INTEGRATION_PROMPT.md`。
