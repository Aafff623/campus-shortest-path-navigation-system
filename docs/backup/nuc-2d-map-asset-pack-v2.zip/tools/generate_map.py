#!/usr/bin/env python3
"""
Generate matching SVG and PNG campus map from campus-layout.json.
Run: python generate_map.py
Outputs: nuc-campus-map-schematic-v2.svg, nuc-campus-map-schematic-v2.png
"""
import json
import math
from PIL import Image, ImageDraw, ImageFont

WIDTH, HEIGHT = 1600, 900

PLACE_COLORS = {
    "teaching": "#2563eb",
    "library": "#7c3aed",
    "canteen": "#ea580c",
    "dorm": "#059669",
    "gym": "#db2777",
    "lab": "#0891b2",
    "hospital": "#dc2626",
    "office": "#4f46e5",
    "playground": "#16a34a",
}

ZONE_COLORS = {
    "northwest-academic": "#eff6ff",
    "north-academic": "#f5f3ff",
    "northeast-service": "#fef2f2",
    "east-dining": "#fff7ed",
    "east-academic": "#ecfeff",
    "southeast-sports": "#fdf2f8",
    "center-sports": "#dcfce7",
    "southwest-living": "#f0fdf4",
    "west-admin": "#eef2ff",
}


def load_layout(path="campus-layout.json"):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def polyline_points(points):
    return " ".join(f"{x},{y}" for x, y in points)


def make_svg(layout):
    places = layout["places"]
    polylines = layout["edgePolylines"]
    road = layout["roadStyle"]

    # Background + zones
    parts = [
        f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {WIDTH} {HEIGHT}" width="{WIDTH}" height="{HEIGHT}">',
        '<defs>',
        '  <linearGradient id="bgGrad" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stop-color="#f8fafc"/><stop offset="1" stop-color="#f1f5f9"/></linearGradient>',
        '  <filter id="nodeShadow" x="-50%" y="-50%" width="200%" height="200%"><feDropShadow dx="0" dy="3" stdDeviation="4" flood-color="#0f172a" flood-opacity="0.15"/></filter>',
        '</defs>',
        f'<rect width="{WIDTH}" height="{HEIGHT}" fill="url(#bgGrad)"/>',
    ]

    # Campus boundary green zone
    parts.append(
        '<path d="M80,120 C240,50 520,60 800,80 C1100,100 1420,70 1520,180 C1560,320 1500,620 1380,760 '
        'C1150,860 720,840 460,800 C240,760 60,600 60,380 C55,260 40,180 80,120 Z" '
        'fill="#f0fdf4" stroke="#bbf7d0" stroke-width="4"/>'
    )

    # Zone tints (building footprints)
    footprint_w = {"teaching": 180, "library": 170, "hospital": 150, "canteen": 170,
                   "lab": 160, "gym": 170, "playground": 220, "dorm": 180, "office": 140}
    footprint_h = {"teaching": 110, "library": 100, "hospital": 100, "canteen": 110,
                   "lab": 120, "gym": 120, "playground": 160, "dorm": 130, "office": 110}
    for pid, p in places.items():
        w = footprint_w.get(pid, 140)
        h = footprint_h.get(pid, 100)
        x = p["x"] - w / 2
        y = p["y"] - h / 2
        fill = ZONE_COLORS.get(p.get("zone", ""), "#f8fafc")
        stroke = PLACE_COLORS.get(pid, "#64748b")
        parts.append(
            f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="18" fill="{fill}" stroke="{stroke}" stroke-width="3" opacity="0.8"/>'
        )

    # Roads (shadow + surface + center line)
    for key, pts in polylines.items():
        parts.append(
            f'<polyline points="{polyline_points(pts)}" fill="none" stroke="{road["stroke"]}" stroke-width="{road["strokeWidth"]}" stroke-linecap="round" stroke-linejoin="round" opacity="0.95"/>'
        )
        parts.append(
            f'<polyline points="{polyline_points(pts)}" fill="none" stroke="{road["centerLineStroke"]}" stroke-width="{road["centerLineWidth"]}" stroke-linecap="round" stroke-linejoin="round" opacity="0.9"/>'
        )

    # Decorative trees
    tree_seed = [(110, 180), (150, 750), (1450, 150), (1480, 780), (540, 110), (980, 110),
                 (180, 320), (1320, 720), (580, 760), (820, 760)]
    for tx, ty in tree_seed:
        parts.append(f'<circle cx="{tx}" cy="{ty}" r="10" fill="#86efac" opacity="0.7"/>')
        parts.append(f'<circle cx="{tx}" cy="{ty}" r="5" fill="#22c55e" opacity="0.8"/>')

    # Place markers
    for pid, p in places.items():
        color = PLACE_COLORS.get(pid, "#64748b")
        ox, oy = p["labelOffset"]
        lx = p["x"] + ox
        ly = p["y"] + oy
        parts.append(
            f'<g filter="url(#nodeShadow)">'
            f'<circle cx="{p["x"]}" cy="{p["y"]}" r="22" fill="#ffffff" stroke="{color}" stroke-width="5"/>'
            f'<circle cx="{p["x"]}" cy="{p["y"]}" r="13" fill="{color}" opacity="0.18"/>'
            f'</g>'
        )
        parts.append(
            f'<text x="{lx}" y="{ly}" text-anchor="middle" font-family="system-ui, -apple-system, Segoe UI, Microsoft YaHei, sans-serif" '
            f'font-size="20" font-weight="700" fill="#1f2937">{p["name"]}</text>'
        )

    # Title + scale + north arrow
    parts += [
        '<text x="60" y="70" font-family="system-ui, -apple-system, Segoe UI, Microsoft YaHei, sans-serif" font-size="32" font-weight="800" fill="#1e293b">中北大学校园 2D 示意平面图</text>',
        '<text x="60" y="108" font-family="system-ui, -apple-system, Segoe UI, Microsoft YaHei, sans-serif" font-size="16" fill="#64748b">示意底图：用于课程设计 Demo；正式图请替换为官方校园平面图或 3D 正射投影结果</text>',
        # Scale bar
        '<g transform="translate(60, 820)">',
        '<rect width="200" height="40" rx="10" fill="#ffffff" stroke="#e2e8f0" opacity="0.95"/>',
        '<line x1="15" y1="28" x2="115" y2="28" stroke="#334155" stroke-width="3"/>',
        '<line x1="15" y1="22" x2="15" y2="34" stroke="#334155" stroke-width="2"/>',
        '<line x1="115" y1="22" x2="115" y2="34" stroke="#334155" stroke-width="2"/>',
        '<text x="15" y="18" font-family="system-ui" font-size="12" fill="#475569">0</text>',
        '<text x="95" y="18" font-family="system-ui" font-size="12" fill="#475569">100 px</text>',
        '<text x="125" y="25" font-family="system-ui" font-size="12" fill="#64748b">(示意比例)</text>',
        '</g>',
        # North arrow
        '<g transform="translate(1480, 80)">',
        '<polygon points="0,0 16,40 -16,40" fill="#1e293b"/>',
        '<text x="0" y="58" text-anchor="middle" font-family="system-ui" font-size="14" font-weight="700" fill="#1e293b">N</text>',
        '</g>',
        # Legend
        '<g transform="translate(1260, 820)">',
        '<rect width="300" height="40" rx="10" fill="#ffffff" stroke="#e2e8f0" opacity="0.95"/>',
        '<line x1="15" y1="20" x2="55" y2="20" stroke="#94a3b8" stroke-width="8" stroke-linecap="round"/>',
        '<text x="65" y="25" font-family="system-ui" font-size="13" fill="#475569">道路</text>',
        '<line x1="110" y1="20" x2="150" y2="20" stroke="#2563eb" stroke-width="6" stroke-linecap="round"/>',
        '<text x="160" y="25" font-family="system-ui" font-size="13" fill="#475569">高亮路径</text>',
        '<circle cx="230" cy="20" r="8" fill="#ffffff" stroke="#dc2626" stroke-width="3"/>',
        '<text x="245" y="25" font-family="system-ui" font-size="13" fill="#475569">地点</text>',
        '</g>',
        '</svg>',
    ]
    return "\n".join(parts)


def make_png(layout, out_path="nuc-campus-map-schematic-v2.png"):
    img = Image.new("RGB", (WIDTH, HEIGHT), "#f1f5f9")
    draw = ImageDraw.Draw(img, "RGBA")

    places = layout["places"]
    polylines = layout["edgePolylines"]
    road = layout["roadStyle"]

    # Try to load a font; fall back to default
    try:
        font_lg = ImageFont.truetype("arial.ttf", 28)
        font_md = ImageFont.truetype("arial.ttf", 18)
        font_sm = ImageFont.truetype("arial.ttf", 14)
        font_xs = ImageFont.truetype("arial.ttf", 12)
    except Exception:
        font_lg = ImageFont.load_default()
        font_md = ImageFont.load_default()
        font_sm = ImageFont.load_default()
        font_xs = ImageFont.load_default()

    # Boundary
    draw.polygon([(80, 120), (240, 50), (520, 60), (800, 80), (1100, 100),
                  (1420, 70), (1520, 180), (1560, 320), (1500, 620), (1380, 760),
                  (1150, 860), (720, 840), (460, 800), (240, 760), (60, 600),
                  (60, 380), (55, 260), (40, 180)], fill="#f0fdf4", outline="#bbf7d0", width=4)

    # Building footprints
    footprint_w = {"teaching": 180, "library": 170, "hospital": 150, "canteen": 170,
                   "lab": 160, "gym": 170, "playground": 220, "dorm": 180, "office": 140}
    footprint_h = {"teaching": 110, "library": 100, "hospital": 100, "canteen": 110,
                   "lab": 120, "gym": 120, "playground": 160, "dorm": 130, "office": 110}
    for pid, p in places.items():
        w = footprint_w.get(pid, 140)
        h = footprint_h.get(pid, 100)
        x = p["x"] - w / 2
        y = p["y"] - h / 2
        fill = ZONE_COLORS.get(p.get("zone", ""), "#f8fafc")
        stroke = PLACE_COLORS.get(pid, "#64748b")
        draw.rounded_rectangle([x, y, x + w, y + h], radius=18, fill=fill, outline=stroke, width=3)

    # Roads
    def draw_polyline(pts, stroke, width):
        for i in range(len(pts) - 1):
            draw.line([pts[i], pts[i + 1]], fill=stroke, width=width)

    for key, pts in polylines.items():
        draw_polyline(pts, road["stroke"], road["strokeWidth"])
        draw_polyline(pts, road["centerLineStroke"], road["centerLineWidth"])

    # Trees
    tree_seed = [(110, 180), (150, 750), (1450, 150), (1480, 780), (540, 110), (980, 110),
                 (180, 320), (1320, 720), (580, 760), (820, 760)]
    for tx, ty in tree_seed:
        draw.ellipse([tx - 10, ty - 10, tx + 10, ty + 10], fill="#86efac")
        draw.ellipse([tx - 5, ty - 5, tx + 5, ty + 5], fill="#22c55e")

    # Markers
    for pid, p in places.items():
        color = PLACE_COLORS.get(pid, "#64748b")
        x, y = p["x"], p["y"]
        ox, oy = p["labelOffset"]
        # Shadow
        draw.ellipse([x - 25, y - 22, x + 25, y + 28], fill=(15, 23, 42, 40))
        draw.ellipse([x - 22, y - 22, x + 22, y + 22], fill="#ffffff", outline=color, width=5)
        draw.ellipse([x - 13, y - 13, x + 13, y + 13], fill=color + "30")
        # Label
        bbox = draw.textbbox((0, 0), p["name"], font=font_md)
        tw = bbox[2] - bbox[0]
        draw.text((x + ox - tw / 2, y + oy - 10), p["name"], fill="#1f2937", font=font_md)

    # Title
    draw.text((60, 50), "中北大学校园 2D 示意平面图", fill="#1e293b", font=font_lg)
    draw.text((60, 95), "示意底图：用于课程设计 Demo；正式图请替换为官方校园平面图或 3D 正射投影结果", fill="#64748b", font=font_sm)

    # Scale bar
    draw.rounded_rectangle([60, 820, 260, 860], radius=10, fill="#ffffff", outline="#e2e8f0", width=2)
    draw.line([(15 + 60, 28 + 820), (115 + 60, 28 + 820)], fill="#334155", width=3)
    draw.text((75, 835), "0", fill="#475569", font=font_xs)
    draw.text((155, 835), "100 px", fill="#475569", font=font_xs)
    draw.text((185, 835), "(示意比例)", fill="#64748b", font=font_xs)

    # North arrow
    draw.polygon([(1480, 80), (1496, 120), (1464, 120)], fill="#1e293b")
    draw.text((1472, 128), "N", fill="#1e293b", font=font_sm)

    # Legend
    draw.rounded_rectangle([1260, 820, 1560, 860], radius=10, fill="#ffffff", outline="#e2e8f0", width=2)
    draw.line([(1275, 840), (1315, 840)], fill="#94a3b8", width=8)
    draw.text((1325, 832), "道路", fill="#475569", font=font_xs)
    draw.line([(1370, 840), (1410, 840)], fill="#2563eb", width=6)
    draw.text((1420, 832), "高亮路径", fill="#475569", font=font_xs)
    draw.ellipse([(1500, 832), (1516, 848)], fill="#ffffff", outline="#dc2626", width=3)
    draw.text((1525, 832), "地点", fill="#475569", font=font_xs)

    img.save(out_path, "PNG")
    print(f"Saved {out_path}")


if __name__ == "__main__":
    layout = load_layout("campus-layout.json")
    svg = make_svg(layout)
    with open("nuc-campus-map-schematic-v2.svg", "w", encoding="utf-8") as f:
        f.write(svg)
    print("Saved nuc-campus-map-schematic-v2.svg")
    make_png(layout)
