#!/usr/bin/env python3
"""
模板：将 3D 模型中的 marker 坐标正射投影到 2D，并生成 campus-layout.json 片段。

用法：
1. 填写 source_materials/model-markers.template.json 中的 3D 坐标和 bounds。
2. （可选）提供道路中心线采样点 source_materials/road-samples.json。
3. 运行：python tools/project_3d_markers_to_2d.py
4. 输出到 project-files/assets/prototype/campus-nav-prototype/data/campus-layout.json
"""
import json
import math


def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def orthographic_project(mx, my, bounds, image_size):
    """正射投影：camera 垂直向下，Z 轴朝上。"""
    min_x, max_x = bounds["minX"], bounds["maxX"]
    min_y, max_y = bounds["minY"], bounds["maxY"]
    w, h = image_size["width"], image_size["height"]
    sx = (mx - min_x) / (max_x - min_x) * w
    sy = h - (my - min_y) / (max_y - min_y) * h
    return round(sx), round(sy)


def build_layout(template, road_samples=None):
    image_size = template["imageSize"]
    bounds = template["bounds"]
    coords = template["modelCoordinates"]

    # 固定元数据（可修改）
    layout = {
        "version": "0.2.0",
        "status": "projected-from-3d-model",
        "note": "由 3D 模型正射投影生成。",
        "map": {
            "name": "中北大学校园 3D 投影平面图",
            "image": "images/nuc-campus-map-official.png",
            "previewImage": "images/nuc-campus-map-official.png",
            "width": image_size["width"],
            "height": image_size["height"],
            "coordinateSystem": "SVG pixel coordinate; origin top-left; x right, y down",
            "source": "3D orthographic projection"
        },
        "places": {},
        "edges": [],  # 从 routes.json 或 graph 数据填充
        "edgePolylines": {},
        "calibration": {
            "method": "3D orthographic projection",
            "metersPerPixel": template.get("modelUnitToMeter", 1.0),
            "realWorldBounds": bounds,
            "notes": "请根据真实测量距离校准 metersPerPixel。"
        }
    }

    for pid, c in coords.items():
        sx, sy = orthographic_project(c["x"], c["y"], bounds, image_size)
        layout["places"][pid] = {
            "name": c.get("name", pid),
            "x": sx,
            "y": sy,
            "labelOffset": [0, -32 if sy < image_size["height"] / 2 else 40]
        }

    if road_samples:
        for pair, points_3d in road_samples.items():
            layout["edgePolylines"][pair] = [
                list(orthographic_project(p["x"], p["y"], bounds, image_size))
                for p in points_3d
            ]

    return layout


if __name__ == "__main__":
    template = load_json("source_materials/model-markers.template.json")
    try:
        road_samples = load_json("source_materials/road-samples.json")
    except FileNotFoundError:
        road_samples = None

    layout = build_layout(template, road_samples)
    out_path = "project-files/assets/prototype/campus-nav-prototype/data/campus-layout.json"
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(layout, f, ensure_ascii=False, indent=2)
    print(f"Written {out_path}")
